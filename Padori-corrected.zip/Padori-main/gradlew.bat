@echo off
setlocal
set "APP_HOME=%~dp0"
set "PROPS=%APP_HOME%gradle\wrapper\gradle-wrapper.properties"

for /f "tokens=1,* delims==" %%A in ('findstr /b "distributionUrl=" "%PROPS%"') do set "DIST_URL=%%B"
set "DIST_URL=%DIST_URL:\:=:%"
set "DIST_URL=%DIST_URL:\=%"
for %%F in ("%DIST_URL%") do set "DIST_NAME=%%~nxF"
set "DIST_BASE=%DIST_NAME:.zip=%"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE_DIR=%GRADLE_USER_HOME%\wrapper\dists\%DIST_BASE%\padori"
set "DIST_DIR=%CACHE_DIR%\%DIST_BASE%"

if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  echo Downloading %DIST_URL%
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%DIST_URL%' -OutFile '%CACHE_DIR%\%DIST_NAME%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%CACHE_DIR%\%DIST_NAME%' '%CACHE_DIR%'"
  del /q "%CACHE_DIR%\%DIST_NAME%"
)

call "%DIST_DIR%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
